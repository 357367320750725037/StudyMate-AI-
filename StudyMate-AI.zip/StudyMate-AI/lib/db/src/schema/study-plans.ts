import {
  index,
  jsonb,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";

export type StoredStudyPlanInput = {
  requestId: string;
  subjects: string[];
  availableHoursPerDay: number;
  startDate: string;
  examDate: string;
  difficulty: "easy" | "moderate" | "hard";
};

export type StoredStudyPlan = {
  overview: string;
  studyDays: Array<{
    date: string;
    focus: string;
    sessions: Array<{
      subject: string;
      activity: "learn" | "practice" | "review" | "mock_exam";
      durationMinutes: number;
      task: string;
    }>;
  }>;
};

export const studyPlans = pgTable(
  "study_plans",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    sessionId: text("session_id").notNull(),
    requestId: uuid("request_id").notNull(),
    input: jsonb("input").$type<StoredStudyPlanInput>().notNull(),
    plan: jsonb("plan").$type<StoredStudyPlan>().notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    sessionRequestUnique: uniqueIndex("study_plans_session_request_unique").on(
      table.sessionId,
      table.requestId,
    ),
    sessionCreatedIndex: index("study_plans_session_created_idx").on(
      table.sessionId,
      table.createdAt,
    ),
  }),
);

import { Router, type IRouter } from "express";
import {
  CreateStudyPlanBody,
  CreateStudyPlanResponse,
  ListStudyPlansResponse,
  SendAgentMessageBody,
  SendAgentMessageResponse,
} from "@workspace/api-zod";
import {
  GeminiRequestError,
  generateStudyPlan,
  orchestrateStudyMateRequest,
} from "../lib/studymate-agent";
import {
  findStudyPlanForRequest,
  getOrCreateStudySession,
  listStudyPlansForSession,
  saveStudyPlanForSession,
  StudySessionError,
} from "../lib/study-plans";

const router: IRouter = Router();

router.post("/agent/messages", async (req, res): Promise<void> => {
  const parsed = SendAgentMessageBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Enter a question before sending it." });
    return;
  }

  const lastMessage = parsed.data.messages.at(-1);
  if (lastMessage?.role !== "user") {
    res.status(400).json({ error: "Send a new question to continue the conversation." });
    return;
  }

  try {
    const result = await orchestrateStudyMateRequest(
      parsed.data.messages,
      process.env.GEMINI_API_KEY,
    );
    res.json(SendAgentMessageResponse.parse(result));
  } catch (error) {
    if (error instanceof GeminiRequestError && error.kind === "missing_key") {
      res.status(503).json({
        error: "Gemini is not configured. Add GEMINI_API_KEY in Replit Secrets and restart the API Server.",
      });
      return;
    }

    if (error instanceof GeminiRequestError) {
      req.log.warn(
        {
          upstreamStatus: error.upstreamStatus,
          upstreamMessage: error.upstreamMessage,
        },
        "Gemini request failed",
      );
    } else {
      req.log.error("StudyMate agent request failed");
    }

    res.status(502).json({
      error: "StudyMate could not get an answer from Gemini right now. Please try again.",
    });
  }
});

router.get("/agent/study-plans", async (req, res): Promise<void> => {
  try {
    const sessionId = getOrCreateStudySession(req, res);
    const plans = await listStudyPlansForSession(sessionId);
    res.json(ListStudyPlansResponse.parse({ plans }));
  } catch (error) {
    if (error instanceof StudySessionError) {
      res.status(503).json({
        error: "Saved plans are unavailable because session signing is not configured.",
      });
      return;
    }

    req.log.error("StudyMate saved plans could not be loaded");
    res.status(500).json({ error: "StudyMate could not load your saved plans. Please try again." });
  }
});

router.post("/agent/study-plans", async (req, res): Promise<void> => {
  const parsed = CreateStudyPlanBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({
      error: "Add 1–8 subjects, study hours from 0.5 to 12 per day, an exam date, and a difficulty.",
    });
    return;
  }

  const input = parsed.data;
  const subjectKeys = input.subjects.map((subject) => subject.trim().toLocaleLowerCase());
  if (subjectKeys.some((subject) => !subject) || new Set(subjectKeys).size !== subjectKeys.length) {
    res.status(400).json({ error: "Enter each subject once, with a distinct name." });
    return;
  }

  const start = Date.parse(`${input.startDate}T00:00:00.000Z`);
  const exam = Date.parse(`${input.examDate}T00:00:00.000Z`);
  const availableDays = (exam - start) / 86_400_000 + 1;
  if (
    !Number.isFinite(start) ||
    !Number.isFinite(exam) ||
    exam <= start ||
    exam - start > 365 * 86_400_000
  ) {
    res.status(400).json({ error: "Choose an exam date from tomorrow through the next 12 months." });
    return;
  }
  if (availableDays * input.availableHoursPerDay * 60 < input.subjects.length * 15) {
    res.status(400).json({
      error: "There is not enough available time to review every subject. Add study hours or choose a later exam date.",
    });
    return;
  }

  let sessionId: string;
  try {
    sessionId = getOrCreateStudySession(req, res);
    const existing = await findStudyPlanForRequest(sessionId, input.requestId);
    if (existing) {
      res.json(CreateStudyPlanResponse.parse(existing));
      return;
    }
  } catch (error) {
    if (error instanceof StudySessionError) {
      res.status(503).json({
        error: "Saved plans are unavailable because session signing is not configured.",
      });
      return;
    }
    req.log.error("StudyMate saved plan lookup failed");
    res.status(500).json({ error: "StudyMate could not check for a saved plan. Please try again." });
    return;
  }

  try {
    const generatedPlan = await generateStudyPlan(input, process.env.GEMINI_API_KEY);
    const savedPlan = await saveStudyPlanForSession(sessionId, input, generatedPlan);
    res.json(CreateStudyPlanResponse.parse(savedPlan));
  } catch (error) {
    if (error instanceof GeminiRequestError && error.kind === "missing_key") {
      res.status(503).json({
        error: "Gemini is not configured. Add GEMINI_API_KEY in Replit Secrets and restart the API Server.",
      });
      return;
    }

    if (error instanceof GeminiRequestError) {
      req.log.warn(
        {
          upstreamStatus: error.upstreamStatus,
          upstreamMessage: error.upstreamMessage,
        },
        "Gemini study plan request failed",
      );
      res.status(502).json({
        error: "StudyMate could not create a valid schedule with Gemini right now. Please try again.",
      });
      return;
    }

    req.log.error("StudyMate study plan could not be saved");
    res.status(500).json({
      error: "Gemini generated the plan, but StudyMate could not save it. Please try again.",
    });
  }
});

export default router;

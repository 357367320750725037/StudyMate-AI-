import { and, desc, eq } from "drizzle-orm";
import type { Request, Response } from "express";
import { randomUUID } from "node:crypto";
import { db, studyPlans } from "@workspace/db";

const SESSION_COOKIE = "studymate_session";
const SESSION_COOKIE_MAX_AGE = 365 * 24 * 60 * 60 * 1000;

export class StudySessionError extends Error {
  constructor() {
    super("Study session signing is not configured.");
    this.name = "StudySessionError";
  }
}

export function getOrCreateStudySession(req: Request, res: Response): string {
  if (!process.env.SESSION_SECRET) throw new StudySessionError();

  const existing = req.signedCookies?.[SESSION_COOKIE];
  if (typeof existing === "string" && /^[0-9a-f-]{36}$/i.test(existing)) {
    return existing;
  }

  const sessionId = randomUUID();
  res.cookie(SESSION_COOKIE, sessionId, {
    signed: true,
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: SESSION_COOKIE_MAX_AGE,
    path: "/api",
  });
  return sessionId;
}

type StudyPlanRow = typeof studyPlans.$inferSelect;

function toPublicStudyPlan(row: StudyPlanRow) {
  return {
    id: row.id,
    requestId: row.requestId,
    input: row.input,
    plan: row.plan,
    createdAt: row.createdAt.toISOString(),
  };
}

export async function listStudyPlansForSession(sessionId: string) {
  const rows = await db
    .select()
    .from(studyPlans)
    .where(eq(studyPlans.sessionId, sessionId))
    .orderBy(desc(studyPlans.createdAt))
    .limit(100);
  return rows.map(toPublicStudyPlan);
}

export async function findStudyPlanForRequest(sessionId: string, requestId: string) {
  const [row] = await db
    .select()
    .from(studyPlans)
    .where(and(eq(studyPlans.sessionId, sessionId), eq(studyPlans.requestId, requestId)))
    .limit(1);
  return row ? toPublicStudyPlan(row) : null;
}

export async function saveStudyPlanForSession(
  sessionId: string,
  input: StudyPlanRow["input"],
  plan: StudyPlanRow["plan"],
) {
  await db
    .insert(studyPlans)
    .values({
      sessionId,
      requestId: input.requestId,
      input,
      plan,
    })
    .onConflictDoNothing({
      target: [studyPlans.sessionId, studyPlans.requestId],
    });

  const saved = await findStudyPlanForRequest(sessionId, input.requestId);
  if (!saved) throw new Error("The saved study plan could not be loaded.");
  return saved;
}

import type {
  AgentChatMessage,
  AgentMessageResponse,
  StudyPlanInput,
  StudyPlanResponse,
} from "@workspace/api-zod";

type AgentTool = AgentMessageResponse["tool"];

type GeminiResponse = {
  candidates?: Array<{
    content?: {
      parts?: Array<{ text?: string }>;
    };
  }>;
};

export class GeminiRequestError extends Error {
  constructor(
    readonly kind: "missing_key" | "upstream",
    readonly upstreamStatus?: number,
    readonly upstreamMessage?: string,
  ) {
    super(kind === "missing_key" ? "Gemini is not configured" : "Gemini request failed");
    this.name = "GeminiRequestError";
  }
}

const toolUnavailableMessages: Record<Exclude<AgentTool, "academic_qa">, string> = {
  study_planner:
    "Use the Study Planner page to generate a schedule. Enter your subjects, available study hours per day, exam date, and difficulty there.",
  attendance_analyzer: "The Attendance Analyzer is planned for a later phase and is not available yet.",
  document_summarizer: "Document summarization is planned for a later phase and is not available yet.",
  academic_report_generator: "The Academic Report Generator is planned for a later phase and is not available yet.",
};

export function selectAgentTool(request: string): AgentTool {
  if (/\b(attendance|absent|absence|present|bunked)\b/i.test(request)) {
    return "attendance_analyzer";
  }

  if (/\b(summarize|summarizing|summary|summarization|summarisation|condense|key points)\b/i.test(request)) {
    return "document_summarizer";
  }

  if (/\b(report|progress report|academic report)\b/i.test(request)) {
    return "academic_report_generator";
  }

  if (/\b(study plan|study schedule|timetable|plan my study|plan a study|schedule my study)\b/i.test(request)) {
    return "study_planner";
  }

  return "academic_qa";
}

async function generateAcademicAnswer(
  messages: AgentChatMessage[],
  apiKey: string | undefined,
  fetcher: typeof fetch = globalThis.fetch,
): Promise<string> {
  if (!apiKey) {
    throw new GeminiRequestError("missing_key");
  }

  let response: Response;
  try {
    response = await fetcher(
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash-lite:generateContent",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": apiKey,
        },
        body: JSON.stringify({
          systemInstruction: {
            parts: [
              {
                text: "You are StudyMate AI, a helpful academic tutor for university students. Explain concepts clearly, accurately, and in student-friendly language. Use concise structure, examples, and step-by-step reasoning when helpful. Be transparent when you are uncertain. Do not claim to have read files or course materials that were not provided. Focus on academic questions; do not pretend to perform planning, attendance analysis, document summarization, or report generation.",
              },
            ],
          },
          contents: messages.map((message) => ({
            role: message.role === "assistant" ? "model" : "user",
            parts: [{ text: message.content }],
          })),
          generationConfig: {
            maxOutputTokens: 8192,
          },
        }),
        signal: AbortSignal.timeout(45_000),
      },
    );
  } catch {
    throw new GeminiRequestError("upstream");
  }

  if (!response.ok) {
    const errorPayload = (await response.json().catch(() => null)) as
      | { error?: { message?: string } }
      | null;
    const upstreamMessage = errorPayload?.error?.message
      ?.replace(/AIza[0-9A-Za-z_-]{20,}/g, "[redacted]")
      .slice(0, 240);
    throw new GeminiRequestError("upstream", response.status, upstreamMessage);
  }

  let payload: GeminiResponse;
  try {
    payload = (await response.json()) as GeminiResponse;
  } catch {
    throw new GeminiRequestError("upstream", response.status);
  }

  const answer = payload.candidates?.[0]?.content?.parts
    ?.map((part) => part.text ?? "")
    .join("")
    .trim();

  if (!answer) {
    throw new GeminiRequestError("upstream", response.status);
  }

  return answer;
}

export async function orchestrateStudyMateRequest(
  messages: AgentChatMessage[],
  apiKey: string | undefined = process.env.GEMINI_API_KEY,
  fetcher: typeof fetch = globalThis.fetch,
): Promise<AgentMessageResponse> {
  const latestRequest = [...messages].reverse().find((message) => message.role === "user");
  if (!latestRequest) {
    throw new Error("A user message is required.");
  }

  const tool = selectAgentTool(latestRequest.content);
  if (tool !== "academic_qa") {
    return {
      tool,
      status: "not_implemented",
      answer: toolUnavailableMessages[tool],
    };
  }

  return {
    tool,
    status: "complete",
    answer: await generateAcademicAnswer(messages, apiKey, fetcher),
  };
}

type GeminiStructuredResponse = {
  candidates?: Array<{
    content?: {
      parts?: Array<{ text?: string }>;
    };
  }>;
};

const studyPlanResponseSchema = {
  type: "OBJECT",
  properties: {
    overview: { type: "STRING" },
    studyDays: {
      type: "ARRAY",
      items: {
        type: "OBJECT",
        properties: {
          date: { type: "STRING" },
          focus: { type: "STRING" },
          sessions: {
            type: "ARRAY",
            items: {
              type: "OBJECT",
              properties: {
                subject: { type: "STRING" },
                activity: {
                  type: "STRING",
                  enum: ["learn", "practice", "review", "mock_exam"],
                },
                durationMinutes: { type: "INTEGER" },
                task: { type: "STRING" },
              },
              required: ["subject", "activity", "durationMinutes", "task"],
            },
          },
        },
        required: ["date", "focus", "sessions"],
      },
    },
  },
  required: ["overview", "studyDays"],
};

function parseCalendarDate(date: string): number | null {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return null;
  const timestamp = Date.parse(`${date}T00:00:00.000Z`);
  if (!Number.isFinite(timestamp) || new Date(timestamp).toISOString().slice(0, 10) !== date) {
    return null;
  }
  return timestamp;
}

function validateStudyPlan(
  plan: StudyPlanResponse,
  input: StudyPlanInput,
): StudyPlanResponse {
  const start = parseCalendarDate(input.startDate);
  const exam = parseCalendarDate(input.examDate);
  if (start === null || exam === null || exam <= start || exam - start > 365 * 86_400_000) {
    throw new GeminiRequestError("upstream");
  }

  const allowedSubjects = new Map(
    input.subjects.map((subject) => [subject.trim().toLocaleLowerCase(), subject.trim()]),
  );
  const coveredSubjects = new Set<string>();
  const scheduledDates = new Set<string>();
  const normalizedDays = plan.studyDays.map((day) => {
    const dayTimestamp = parseCalendarDate(day.date);
    if (
      dayTimestamp === null ||
      dayTimestamp < start ||
      dayTimestamp > exam ||
      scheduledDates.has(day.date)
    ) {
      throw new GeminiRequestError("upstream");
    }
    scheduledDates.add(day.date);

    const totalMinutes = day.sessions.reduce((total, session) => total + session.durationMinutes, 0);
    if (totalMinutes > input.availableHoursPerDay * 60) {
      throw new GeminiRequestError("upstream");
    }

    return {
      ...day,
      sessions: day.sessions.map((session) => {
        const subject = allowedSubjects.get(session.subject.trim().toLocaleLowerCase());
        if (!subject) throw new GeminiRequestError("upstream");
        coveredSubjects.add(subject.toLocaleLowerCase());
        return { ...session, subject };
      }),
    };
  });

  if ([...allowedSubjects.keys()].some((subject) => !coveredSubjects.has(subject))) {
    throw new GeminiRequestError("upstream");
  }

  return { ...plan, studyDays: normalizedDays };
}

export async function generateStudyPlan(
  input: StudyPlanInput,
  apiKey: string | undefined = process.env.GEMINI_API_KEY,
  fetcher: typeof fetch = globalThis.fetch,
): Promise<StudyPlanResponse> {
  if (!apiKey) throw new GeminiRequestError("missing_key");

  const prompt = [
    "Create a realistic, personalized study schedule for a university student.",
    "Use the provided local start date and exam date. Schedule only dates from the start date through the exam date.",
    "Include every supplied subject at least once, and do not invent additional subjects.",
    "Choose a sustainable number of study days and sessions based on the time available and the selected difficulty.",
    "Each day's total session minutes must not exceed availableHoursPerDay. Sessions should use active recall, practice, and spaced review where appropriate.",
    "Keep the last day before the exam light and focused on review; do not schedule heavy new learning on the exam date.",
    "Return only the requested JSON object. Dates must use YYYY-MM-DD. Each session subject must exactly match one supplied subject.",
    `Student inputs:\n${JSON.stringify({
      subjects: input.subjects,
      availableHoursPerDay: input.availableHoursPerDay,
      startDate: input.startDate,
      examDate: input.examDate,
      difficulty: input.difficulty,
    }, null, 2)}`,
  ].join("\n\n");

  let response: Response;
  try {
    response = await fetcher(
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash-lite:generateContent",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": apiKey,
        },
        body: JSON.stringify({
          systemInstruction: {
            parts: [
              {
                text: "You are StudyMate AI's academic study planner. Prioritize sustainable workload, spaced review, and realistic session lengths. Return valid JSON matching the supplied response schema and do not add claims that are not supported by the student's inputs.",
              },
            ],
          },
          contents: [{ role: "user", parts: [{ text: prompt }] }],
          generationConfig: {
            maxOutputTokens: 8192,
            responseMimeType: "application/json",
            responseSchema: studyPlanResponseSchema,
          },
        }),
        signal: AbortSignal.timeout(60_000),
      },
    );
  } catch {
    throw new GeminiRequestError("upstream");
  }

  if (!response.ok) {
    const errorPayload = (await response.json().catch(() => null)) as
      | { error?: { message?: string } }
      | null;
    const upstreamMessage = errorPayload?.error?.message
      ?.replace(/AIza[0-9A-Za-z_-]{20,}/g, "[redacted]")
      .slice(0, 240);
    throw new GeminiRequestError("upstream", response.status, upstreamMessage);
  }

  let payload: GeminiStructuredResponse;
  try {
    payload = (await response.json()) as GeminiStructuredResponse;
  } catch {
    throw new GeminiRequestError("upstream", response.status);
  }

  const generatedJson = payload.candidates?.[0]?.content?.parts
    ?.map((part) => part.text ?? "")
    .join("")
    .trim();
  if (!generatedJson) throw new GeminiRequestError("upstream", response.status);

  let parsed: StudyPlanResponse;
  try {
    parsed = JSON.parse(generatedJson) as StudyPlanResponse;
  } catch {
    throw new GeminiRequestError("upstream", response.status);
  }

  return validateStudyPlan(parsed, input);
}

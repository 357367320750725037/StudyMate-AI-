import { zodResolver } from '@hookform/resolvers/zod';
import {
  getListStudyPlansQueryKey,
  useCreateStudyPlan,
  useListStudyPlans,
  type SavedStudyPlan,
  type SavedStudyPlansResponse,
} from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';
import { useRef, useState } from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import {
  AlertCircle,
  CalendarDays,
  Check,
  Clock3,
  LoaderCircle,
  Sparkles,
} from 'lucide-react';

const plannerFormSchema = z.object({
  subjects: z.string().trim().min(1, 'Add at least one subject, one per line.').max(640, 'Keep the subject list under 640 characters.'),
  availableHoursPerDay: z.coerce.number().min(0.5, 'Enter at least 0.5 hours per day.').max(12, 'Enter no more than 12 hours per day.').multipleOf(0.5, 'Use half-hour increments.'),
  examDate: z.string().min(1, 'Choose your exam date.'),
  difficulty: z.enum(['easy', 'moderate', 'hard']),
}).superRefine((values, context) => {
  const subjects = values.subjects
    .split(/\r?\n/)
    .map((subject) => subject.trim())
    .filter(Boolean);
  const normalized = subjects.map((subject) => subject.toLocaleLowerCase());

  if (!subjects.length) {
    context.addIssue({ code: z.ZodIssueCode.custom, path: ['subjects'], message: 'Add at least one subject.' });
  }
  if (subjects.length > 8) {
    context.addIssue({ code: z.ZodIssueCode.custom, path: ['subjects'], message: 'Add no more than 8 subjects.' });
  }
  if (new Set(normalized).size !== normalized.length) {
    context.addIssue({ code: z.ZodIssueCode.custom, path: ['subjects'], message: 'Remove duplicate subject names.' });
  }
});

type PlannerFormInput = z.input<typeof plannerFormSchema>;
type PlannerFormValues = z.output<typeof plannerFormSchema>;

function localDateOffset(days: number): string {
  const date = new Date();
  date.setDate(date.getDate() + days);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function getFriendlyError(
  error: unknown,
  fallback = 'StudyMate could not connect to Gemini. Check your connection and try again.',
): string {
  if (error && typeof error === 'object' && 'data' in error) {
    const data = error.data;
    if (data && typeof data === 'object' && 'error' in data && typeof data.error === 'string') {
      return data.error;
    }
  }
  return fallback;
}

function formatDate(date: string): string {
  return new Intl.DateTimeFormat(undefined, {
    weekday: 'long',
    month: 'short',
    day: 'numeric',
  }).format(new Date(`${date}T12:00:00`));
}

function formatSavedDate(date: string): string {
  return new Intl.DateTimeFormat(undefined, {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  }).format(new Date(date));
}

const activityLabels = {
  learn: 'Learn',
  practice: 'Practice',
  review: 'Review',
  mock_exam: 'Mock exam',
} as const;

export function StudyPlannerPage() {
  const [requestError, setRequestError] = useState<string | null>(null);
  const [saveSuccess, setSaveSuccess] = useState<string | null>(null);
  const [selectedPlanId, setSelectedPlanId] = useState<string | null>(null);
  const requestIdRef = useRef<{ signature: string; requestId: string } | null>(null);
  const studyPlanRequest = useCreateStudyPlan();
  const savedPlansQuery = useListStudyPlans();
  const queryClient = useQueryClient();
  const savedPlans = savedPlansQuery.data?.plans ?? [];
  const currentSavedPlan: SavedStudyPlan | null =
    savedPlans.find((savedPlan) => savedPlan.id === selectedPlanId) ?? savedPlans[0] ?? null;
  const plan = currentSavedPlan?.plan ?? null;
  const form = useForm<PlannerFormInput, unknown, PlannerFormValues>({
    resolver: zodResolver(plannerFormSchema),
    defaultValues: {
      subjects: '',
      availableHoursPerDay: 2,
      examDate: '',
      difficulty: 'moderate',
    },
  });

  async function submitPlan(values: PlannerFormValues) {
    setRequestError(null);
    setSaveSuccess(null);
    setSelectedPlanId(null);
    const subjects = values.subjects
      .split(/\r?\n/)
      .map((subject) => subject.trim())
      .filter(Boolean);
    const planInput = {
      subjects,
      availableHoursPerDay: values.availableHoursPerDay,
      startDate: localDateOffset(0),
      examDate: values.examDate,
      difficulty: values.difficulty,
    };
    const signature = JSON.stringify(planInput);
    if (requestIdRef.current?.signature !== signature) {
      requestIdRef.current = { signature, requestId: crypto.randomUUID() };
    }

    try {
      const generatedPlan = await studyPlanRequest.mutateAsync({
        data: {
          ...planInput,
          requestId: requestIdRef.current.requestId,
        },
      });
      queryClient.setQueryData<SavedStudyPlansResponse>(
        getListStudyPlansQueryKey(),
        (current) => ({
          plans: [
            generatedPlan,
            ...(current?.plans ?? []).filter((savedPlan) => savedPlan.id !== generatedPlan.id),
          ].slice(0, 100),
        }),
      );
      setSelectedPlanId(generatedPlan.id);
      setSaveSuccess('Your plan is saved for this browser session and will be here after a refresh.');
      requestIdRef.current = null;
    } catch (error) {
      setRequestError(getFriendlyError(error));
    }
  }

  const totalMinutes = plan?.studyDays.reduce(
    (total, day) => total + day.sessions.reduce((dayTotal, session) => dayTotal + session.durationMinutes, 0),
    0,
  ) ?? 0;

  return (
    <main className="page-wrap" data-testid="page-study-planner">
      <div className="page-heading">
        <div>
          <div className="eyebrow">Make time for what matters</div>
          <h1>Study Planner</h1>
          <p>Share your subjects, available study time, exam date, and difficulty. Gemini will build a realistic schedule around them.</p>
        </div>
        <span className="phase-badge"><span className="online-dot" /> Gemini study planning active</span>
      </div>

      <div className="feature-layout">
        <section className="feature-panel" aria-labelledby="planner-panel-title">
          <div className="panel-top">
            <div>
              <h2 id="planner-panel-title">Build your study schedule</h2>
              <p>A flexible plan shaped around your exam</p>
            </div>
            <CalendarDays size={19} color="#528271" strokeWidth={1.7} />
          </div>
          <div className="preview-body planner-body">
            <Form {...form}>
              <form
                className="planner-form"
                onSubmit={form.handleSubmit(submitPlan)}
                aria-busy={studyPlanRequest.isPending}
                noValidate
              >
                <div className="planner-form-grid">
                  <FormField
                    control={form.control}
                    name="subjects"
                    render={({ field }) => (
                      <FormItem className="planner-field planner-field-wide">
                        <FormLabel className="planner-label">Subjects</FormLabel>
                        <FormControl>
                          <Textarea
                            {...field}
                            className="planner-textarea"
                            placeholder={'Biology\nChemistry\nCalculus'}
                            rows={4}
                            disabled={studyPlanRequest.isPending}
                            data-testid="input-planner-subjects"
                          />
                        </FormControl>
                        <FormDescription className="planner-help">Add 1–8 subjects, one per line.</FormDescription>
                        <FormMessage className="planner-field-error" />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="availableHoursPerDay"
                    render={({ field }) => (
                      <FormItem className="planner-field">
                        <FormLabel className="planner-label">Available study hours per day</FormLabel>
                        <FormControl>
                          <Input
                            {...field}
                            type="number"
                            min={0.5}
                            max={12}
                            step={0.5}
                            className="planner-input"
                            disabled={studyPlanRequest.isPending}
                            data-testid="input-planner-hours"
                          />
                        </FormControl>
                        <FormDescription className="planner-help">Use half-hour increments, from 0.5 to 12 hours.</FormDescription>
                        <FormMessage className="planner-field-error" />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="examDate"
                    render={({ field }) => (
                      <FormItem className="planner-field">
                        <FormLabel className="planner-label">Exam date</FormLabel>
                        <FormControl>
                          <Input
                            {...field}
                            type="date"
                            min={localDateOffset(1)}
                            max={localDateOffset(365)}
                            className="planner-input"
                            disabled={studyPlanRequest.isPending}
                            data-testid="input-planner-exam-date"
                          />
                        </FormControl>
                        <FormDescription className="planner-help">Choose a date within the next 12 months.</FormDescription>
                        <FormMessage className="planner-field-error" />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="difficulty"
                    render={({ field }) => (
                      <FormItem className="planner-field">
                        <FormLabel className="planner-label">Difficulty</FormLabel>
                        <Select
                          value={field.value}
                          onValueChange={field.onChange}
                          disabled={studyPlanRequest.isPending}
                        >
                          <FormControl>
                            <SelectTrigger className="planner-select-trigger" data-testid="select-planner-difficulty">
                              <SelectValue placeholder="Choose a difficulty" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="easy">Easy — lighter review</SelectItem>
                            <SelectItem value="moderate">Moderate — steady pace</SelectItem>
                            <SelectItem value="hard">Hard — more challenging material</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormDescription className="planner-help">How challenging does the material feel?</FormDescription>
                        <FormMessage className="planner-field-error" />
                      </FormItem>
                    )}
                  />
                </div>

                {requestError && (
                  <div className="planner-error" role="alert" data-testid="planner-error">
                    <AlertCircle size={16} />
                    <span>{requestError}</span>
                    <button
                      type="button"
                      className="retry-button"
                      disabled={studyPlanRequest.isPending}
                      onClick={() => void form.handleSubmit(submitPlan)()}
                    >
                      Try again
                    </button>
                  </div>
                )}

                <div className="planner-actions">
                  <button
                    type="submit"
                    className="button-primary"
                    disabled={studyPlanRequest.isPending}
                    data-testid="button-generate-study-plan"
                  >
                    {studyPlanRequest.isPending
                      ? <><LoaderCircle className="loading-spinner" size={15} /> Building your plan…</>
                      : <><Sparkles size={15} /> Generate study plan</>}
                  </button>
                  {studyPlanRequest.isPending && (
                    <span className="planner-pending" role="status">Gemini is organizing your study sessions.</span>
                  )}
                </div>
              </form>
            </Form>

            {savedPlansQuery.isPending && (
              <div className="planner-empty" role="status">
                <span className="notice-icon"><LoaderCircle className="loading-spinner" size={16} /></span>
                <span><strong>Checking for saved plans…</strong><span>Your plans are stored with this browser session.</span></span>
              </div>
            )}

            {savedPlansQuery.isError && (
              <div className="planner-error" role="alert" data-testid="saved-plans-error">
                <AlertCircle size={16} />
                <span>{getFriendlyError(savedPlansQuery.error, 'Saved plans could not be loaded. Check your connection and retry.')}</span>
                <button
                  type="button"
                  className="retry-button"
                  disabled={savedPlansQuery.isFetching}
                  onClick={() => void savedPlansQuery.refetch()}
                >
                  {savedPlansQuery.isFetching ? 'Loading…' : 'Retry'}
                </button>
              </div>
            )}

            {saveSuccess && (
              <div className="planner-success" role="status" data-testid="study-plan-saved">
                <Check size={15} />
                <span>{saveSuccess}</span>
              </div>
            )}

            {savedPlans.length > 0 && (
              <section className="planner-saved-plans" aria-label="Saved study plans">
                <div className="planner-saved-heading">
                  <h3>Saved plans</h3>
                  <span>{savedPlans.length}</span>
                </div>
                <div className="planner-saved-list">
                  {savedPlans.map((savedPlan) => (
                    <button
                      type="button"
                      className={`planner-saved-plan${currentSavedPlan?.id === savedPlan.id ? ' is-active' : ''}`}
                      key={savedPlan.id}
                      aria-pressed={currentSavedPlan?.id === savedPlan.id}
                      onClick={() => {
                        setSelectedPlanId(savedPlan.id);
                        setSaveSuccess(null);
                        setRequestError(null);
                      }}
                    >
                      <span className="planner-saved-plan-copy">
                        <strong>{savedPlan.input.subjects.join(' · ')}</strong>
                        <span>Exam {formatDate(savedPlan.input.examDate)} · Saved {formatSavedDate(savedPlan.createdAt)}</span>
                      </span>
                      {currentSavedPlan?.id === savedPlan.id && <Check size={15} aria-hidden="true" />}
                    </button>
                  ))}
                </div>
              </section>
            )}

            {plan ? (
              <section className="planner-output" aria-label="Generated study schedule" aria-live="polite" data-testid="study-plan-results">
                <div className="planner-output-head">
                  <div>
                    <span className="planner-generated-label"><Check size={13} /> Gemini generated your plan</span>
                    <h3>Your personalized schedule</h3>
                    <p>{plan.overview}</p>
                  </div>
                  <div className="planner-total">
                    <strong>{(totalMinutes / 60).toFixed(1)}</strong>
                    <span>study hours</span>
                  </div>
                </div>
                <div className="planner-schedule">
                  {plan.studyDays.map((day) => (
                    <article className="planner-day" key={day.date}>
                      <div className="planner-day-heading">
                        <div>
                          <span className="planner-day-date">{formatDate(day.date)}</span>
                          <h4>{day.focus}</h4>
                        </div>
                        <span className="planner-day-time">
                          <Clock3 size={13} />
                          {day.sessions.reduce((sum, session) => sum + session.durationMinutes, 0)} min
                        </span>
                      </div>
                      <div className="planner-sessions">
                        {day.sessions.map((session, index) => (
                          <div className="planner-session" key={`${day.date}-${session.subject}-${index}`}>
                            <span className="planner-activity">{activityLabels[session.activity]}</span>
                            <strong>{session.subject}</strong>
                            <p>{session.task}</p>
                            <span className="planner-session-duration">{session.durationMinutes} min</span>
                          </div>
                        ))}
                      </div>
                    </article>
                  ))}
                </div>
                <p className="planner-footnote">Unlisted dates are left open for rest or flexibility. Adjust this schedule to fit your week.</p>
              </section>
            ) : !requestError && !studyPlanRequest.isPending && !savedPlansQuery.isPending && !savedPlansQuery.isError ? (
              <div className="planner-empty" role="status">
                <span className="notice-icon"><Sparkles size={17} /></span>
                <span><strong>Your schedule will appear here.</strong><span>Enter your details above to generate a dated plan with Gemini.</span></span>
              </div>
            ) : null}
          </div>
        </section>

        <aside className="side-note" data-testid="panel-planner-note">
          <CalendarDays size={20} strokeWidth={1.7} />
          <h3>Progress over perfection.</h3>
          <p>A useful plan should support your life—not add another thing to keep up with. Every session is tailored to the details you enter.</p>
        </aside>
      </div>
    </main>
  );
}

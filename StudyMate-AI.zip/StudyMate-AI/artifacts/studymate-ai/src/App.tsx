import { type FormEvent, type ReactNode, useEffect, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import {
  useSendAgentMessage,
  type AgentChatMessage,
  type AgentMessageResponse,
} from '@workspace/api-client-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { StudyPlannerPage } from '@/pages/study-planner-page';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import {
  ArrowRight,
  ArrowUpRight,
  BookOpen,
  CalendarDays,
  ChartNoAxesColumnIncreasing,
  Check,
  ChevronRight,
  Clock3,
  FileText,
  GraduationCap,
  LayoutDashboard,
  LoaderCircle,
  Lightbulb,
  MessageCircle,
  Send,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';
import { Link, Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

const queryClient = new QueryClient();

const pages = [
  { label: 'Dashboard', href: '/', icon: LayoutDashboard },
  { label: 'Ask AI', href: '/ask-ai', icon: MessageCircle },
  { label: 'Study Planner', href: '/study-planner', icon: CalendarDays },
  { label: 'Summarize Material', href: '/summarize-material', icon: BookOpen },
  { label: 'Attendance Analyzer', href: '/attendance-analyzer', icon: ChartNoAxesColumnIncreasing },
  { label: 'Report Generator', href: '/report-generator', icon: FileText },
];

const toolCards = [
  { title: 'Study Planner', description: 'Bring your deadlines, classes and focus time into one clear view.', href: '/study-planner', icon: CalendarDays, tint: false },
  { title: 'Summarize Material', description: 'Turn dense course material into concise, reviewable notes.', href: '/summarize-material', icon: BookOpen, tint: false },
  { title: 'Attendance Analyzer', description: 'Understand attendance patterns and stay on top of course requirements.', href: '/attendance-analyzer', icon: ChartNoAxesColumnIncreasing, tint: false },
  { title: 'Report Generator', description: 'Shape your academic progress into a clear, useful report.', href: '/report-generator', icon: FileText, tint: false },
];

function Sidebar({ active }: { active: string }) {
  return (
    <aside className="sidebar" aria-label="Main navigation">
      <Link href="/" className="brand" data-testid="link-brand">
        <span className="brand-mark"><GraduationCap size={21} strokeWidth={1.8} /></span>
        <span><span className="brand-name">StudyMate AI</span><span className="brand-sub">Your study companion</span></span>
      </Link>
      <p className="nav-caption">Workspace</p>
      <nav className="nav-list">
        {pages.map(({ label, href, icon: Icon }) => (
          <Link key={href} href={href} className={`nav-link${active === href ? ' active' : ''}`} aria-current={active === href ? 'page' : undefined} data-testid={`nav-${href === '/' ? 'dashboard' : href.slice(1)}`}>
            <Icon size={17} strokeWidth={1.8} /><span>{label}</span>
          </Link>
        ))}
      </nav>
      <div className="sidebar-bottom">
        <div className="semester-note" data-testid="card-semester-progress">
          <span className="semester-label">Your semester</span>
          <p>Make room for<br />steady progress.</p>
          <div className="semester-track" aria-label="Semester progress illustration"><span /></div>
          <div className="semester-foot"><span>Fall term</span><span>In progress</span></div>
        </div>
      </div>
    </aside>
  );
}

function MobileNav({ active }: { active: string }) {
  return (
    <nav className="mobile-nav" aria-label="Mobile navigation">
      {pages.map(({ label, href, icon: Icon }) => (
        <Link key={href} href={href} className={active === href ? 'active' : ''} aria-current={active === href ? 'page' : undefined} data-testid={`mobile-nav-${href === '/' ? 'dashboard' : href.slice(1)}`}>
          <Icon size={16} strokeWidth={1.9} /><span>{label === 'Summarize Material' ? 'Summarize' : label === 'Attendance Analyzer' ? 'Attendance' : label === 'Report Generator' ? 'Reports' : label}</span>
        </Link>
      ))}
    </nav>
  );
}

function Header({ active }: { active: string }) {
  const title = pages.find((page) => page.href === active)?.label ?? 'Dashboard';
  return (
    <header className="topbar">
      <Link className="mobile-head" href="/" data-testid="mobile-brand">
        <span className="brand-mark"><GraduationCap size={17} /></span><span>StudyMate AI</span>
      </Link>
      <div className="crumb" aria-label="Breadcrumb"><span>Workspace</span><ChevronRight size={13} /><strong>{title}</strong></div>
      <div className="top-right">
        <span className="today-pill"><Clock3 size={13} /> A little progress, every day</span>
        <span className="avatar" aria-label="Student profile">ST</span>
      </div>
    </header>
  );
}

function Shell({ children, active }: { children: ReactNode; active: string }) {
  return (
    <div className="app-shell">
      <Sidebar active={active} />
      <div className="main-area">
        <Header active={active} />
        {children}
      </div>
      <MobileNav active={active} />
    </div>
  );
}

function HomePage() {
  return (
    <main className="page-wrap" data-testid="page-dashboard">
      <section className="hero" aria-labelledby="home-title">
        <div className="hero-content">
          <div className="eyebrow">A clearer way through your semester</div>
          <h1 id="home-title">Study smarter.<br />Plan better.<br /><span>Achieve more.</span></h1>
          <p className="hero-copy">StudyMate AI is your intelligent academic assistant, designed to help you understand, organize and manage your academic work.</p>
          <div className="hero-actions">
            <Link href="/ask-ai" className="button-primary" data-testid="button-ask-studymate">
              Ask StudyMate AI <ArrowUpRight size={15} />
            </Link>
            <Link href="/study-planner" className="button-quiet" data-testid="button-explore-planner">Explore your tools</Link>
          </div>
        </div>
        <div className="hero-orbit" aria-hidden="true"><Sparkles size={55} strokeWidth={1.2} /></div>
      </section>

      <section aria-labelledby="tools-heading">
        <div className="welcome-row">
          <div>
            <div className="eyebrow">Your academic toolkit</div>
            <h2 className="section-title" id="tools-heading">A little help, right where you need it.</h2>
            <p className="section-description">Choose a space to get started. Each tool is being prepared for Phase 2.</p>
          </div>
          <Link href="/ask-ai" className="small-link" data-testid="link-tool-overview">Ask a question <ArrowRight size={14} /></Link>
        </div>
        <div className="tools-grid">
          <Link href="/ask-ai" className="tool-card featured" data-testid="card-tool-ask-ai">
            <span className="tool-icon"><MessageCircle size={19} /></span>
            <span className="tool-title">Ask StudyMate AI</span>
            <span className="tool-desc">A calm place to get help understanding what you're learning.</span>
            <span className="tool-arrow"><ArrowUpRight size={16} /></span>
          </Link>
          {toolCards.map(({ title, description, href, icon: Icon }) => (
            <Link href={href} key={href} className="tool-card" data-testid={`card-tool-${href.slice(1)}`}>
              <span className="tool-icon"><Icon size={19} /></span>
              <span className="tool-title">{title}</span>
              <span className="tool-desc">{description}</span>
              <span className="tool-arrow"><ArrowUpRight size={16} /></span>
            </Link>
          ))}
        </div>
      </section>

      <section className="home-lower" aria-label="Getting started">
        <div className="quiet-panel" data-testid="panel-gentle-start">
          <div>
            <div className="eyebrow">Start somewhere small</div>
            <h3>Your next step can be simple.</h3>
            <p>Pick one tool, explore what it will do, and come back whenever you're ready for more.</p>
          </div>
          <span className="panel-mark"><Lightbulb size={28} strokeWidth={1.5} /></span>
        </div>
        <div className="quiet-panel" data-testid="panel-product-principles">
          <div>
            <div className="eyebrow">Built around your study life</div>
            <div className="mini-list">
              <div className="mini-item"><span className="mini-check"><Check size={13} /></span>Clear, focused study support</div>
              <div className="mini-item"><span className="mini-check"><Check size={13} /></span>Tools for a busy semester</div>
              <div className="mini-item"><span className="mini-check"><Check size={13} /></span>Your work stays yours</div>
            </div>
          </div>
          <ShieldCheck className="panel-mark" size={28} strokeWidth={1.5} />
        </div>
      </section>
    </main>
  );
}

type PreviewKey = 'summary' | 'attendance' | 'report';

const previews: Record<PreviewKey, { title: string; eyebrow: string; description: string; panelTitle: string; panelSub: string; noticeTitle: string; notice: string; steps: [string, string][]; sideTitle: string; sideText: string; icon: typeof CalendarDays }> = {
  summary: {
    title: 'Summarize Material', eyebrow: 'Make complex ideas easier to revisit', description: 'A focused space for turning course material into study-ready notes. Material processing is not available in this Phase 1 preview.',
    panelTitle: 'A more useful way to review', panelSub: 'A preview of the experience ahead',
    noticeTitle: 'Summarization is coming in Phase 2', notice: 'The future tool will help you work through learning materials and find a clearer path back to the key ideas.',
    steps: [['Choose what to review', 'Bring a topic or course material into focus'], ['Find the main ideas', 'Separate essential concepts from the detail'], ['Return to it with ease', 'Build a clear resource for your revision']],
    sideTitle: 'Understand, then remember.', sideText: 'Good study notes don’t replace learning. They make it easier to return, connect and keep going.', icon: BookOpen,
  },
  attendance: {
    title: 'Attendance Analyzer', eyebrow: 'Stay informed about your classes', description: 'A future home for a clearer view of your attendance. No records are collected or calculations performed in this preview.',
    panelTitle: 'Your attendance overview', panelSub: 'A preview of the experience ahead',
    noticeTitle: 'Attendance insights are in development', notice: 'In Phase 2, this space will help you organize attendance information and understand your course requirements.',
    steps: [['Organize course records', 'Keep class information in one place'], ['Understand requirements', 'Review policies and attendance expectations'], ['Know where you stand', 'See a clear summary to guide next steps']],
    sideTitle: 'Clarity makes a difference.', sideText: 'Know what your course expects so you can make informed choices about your time.', icon: ChartNoAxesColumnIncreasing,
  },
  report: {
    title: 'Report Generator', eyebrow: 'Reflect on your academic progress', description: 'A future space to bring your semester activity into a thoughtful overview. Report generation is not active in Phase 1.',
    panelTitle: 'A report that tells your story', panelSub: 'A preview of the experience ahead',
    noticeTitle: 'Reports are coming in Phase 2', notice: 'The future report experience will help you bring academic progress together in a useful, easy-to-read format.',
    steps: [['Gather what matters', 'Bring relevant academic information together'], ['See the bigger picture', 'Review themes and progress over time'], ['Share or save your summary', 'Create a clear record when you need it']],
    sideTitle: 'Notice how far you’ve come.', sideText: 'A little reflection can help you see the work behind your progress and choose what comes next.', icon: FileText,
  },
};

function FeaturePreview({ kind }: { kind: PreviewKey }) {
  const feature = previews[kind];
  const Icon = feature.icon;
  return (
    <main className="page-wrap" data-testid={`page-${kind}`}>
      <div className="page-heading">
        <div>
          <div className="eyebrow">{feature.eyebrow}</div>
          <h1>{feature.title}</h1>
          <p>{feature.description}</p>
        </div>
        <span className="phase-badge"><Clock3 size={13} /> Phase 2 preview</span>
      </div>
      <div className="feature-layout">
        <section className="feature-panel" aria-labelledby="preview-panel-title">
          <div className="panel-top">
            <div><h2 id="preview-panel-title">{feature.panelTitle}</h2><p>{feature.panelSub}</p></div>
            <Icon size={19} color="#528271" strokeWidth={1.7} />
          </div>
          <div className="preview-body">
            <div className="preview-notice" role="status" data-testid={`status-${kind}-preview`}>
              <span className="notice-icon"><Sparkles size={17} /></span>
              <span><h3>{feature.noticeTitle}</h3><p>{feature.notice}</p></span>
            </div>
            <div className="preview-stages" aria-label="Planned experience">
              {feature.steps.map(([title, detail], index) => (
                <div className="stage-row" key={title} data-testid={`stage-${kind}-${index + 1}`}>
                  <span className="stage-number">0{index + 1}</span>
                  <span className="stage-copy"><strong>{title}</strong><span>{detail}</span></span>
                </div>
              ))}
            </div>
          </div>
        </section>
        <aside className="side-note" data-testid={`panel-${kind}-note`}>
          <Icon size={20} strokeWidth={1.7} />
          <h3>{feature.sideTitle}</h3>
          <p>{feature.sideText}</p>
        </aside>
      </div>
    </main>
  );
}

function AskAiPage() {
  type ChatMessage = AgentChatMessage & {
    id: string;
    tool?: AgentMessageResponse['tool'];
    status?: AgentMessageResponse['status'];
  };

  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [draft, setDraft] = useState('');
  const [requestError, setRequestError] = useState<string | null>(null);
  const messageStageRef = useRef<HTMLDivElement>(null);
  const agentRequest = useSendAgentMessage();

  useEffect(() => {
    const stage = messageStageRef.current;
    if (stage) stage.scrollTo({ top: stage.scrollHeight, behavior: 'smooth' });
  }, [messages, agentRequest.isPending]);

  function getFriendlyError(error: unknown): string {
    if (error && typeof error === 'object' && 'data' in error) {
      const data = error.data;
      if (data && typeof data === 'object' && 'error' in data && typeof data.error === 'string') {
        return data.error;
      }
    }
    return 'StudyMate could not connect to Gemini right now. Check your connection and try again.';
  }

  async function requestAnswer(conversation: ChatMessage[]) {
    setRequestError(null);
    try {
      const result = await agentRequest.mutateAsync({
        data: {
          messages: conversation.slice(-12).map(({ role, content }) => ({ role, content })),
        },
      });
      setMessages((current) => [
        ...current,
        {
          id: crypto.randomUUID(),
          role: 'assistant',
          content: result.answer,
          tool: result.tool,
          status: result.status,
        },
      ]);
    } catch (error) {
      setRequestError(getFriendlyError(error));
    }
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const content = draft.trim();
    if (!content || agentRequest.isPending) return;

    const nextMessage: ChatMessage = {
      id: crypto.randomUUID(),
      role: 'user',
      content,
    };
    const nextConversation = [...messages, nextMessage];
    setMessages(nextConversation);
    setDraft('');
    await requestAnswer(nextConversation);
  }

  async function retryLastQuestion() {
    if (agentRequest.isPending) return;
    await requestAnswer(messages);
  }

  return (
    <main className="page-wrap" data-testid="page-ask-ai">
      <div className="page-heading">
        <div>
          <div className="eyebrow">Your study companion</div>
          <h1>Ask StudyMate AI</h1>
          <p>Bring a concept, question or study challenge. Get a clear, student-friendly explanation to help you learn.</p>
        </div>
        <span className="phase-badge"><span className="online-dot" /> Academic Q&amp;A active</span>
      </div>
      <div className="chat-wrap">
        <section className="chat-shell" aria-label="StudyMate AI chat" aria-busy={agentRequest.isPending}>
          <div className="chat-head">
            <div className="chat-person">
              <span className="chat-mark"><Sparkles size={18} /></span>
              <span><strong>StudyMate AI</strong><span><span className="online-dot" />Academic Q&amp;A · Gemini</span></span>
            </div>
            <span className="phase-badge"><ShieldCheck size={13} /> Your study space</span>
          </div>
          <div
            className={`chat-stage${messages.length ? ' has-messages' : ''}`}
            ref={messageStageRef}
            data-testid="region-chat-messages"
            aria-live="polite"
            aria-relevant="additions text"
          >
            {messages.length === 0 ? (
              <div className="chat-empty">
                <span className="chat-empty-icon"><MessageCircle size={25} strokeWidth={1.6} /></span>
                <h2>A thoughtful answer starts here.</h2>
                <p>Ask an academic question for a clear explanation, a worked example, or a step-by-step walkthrough.</p>
              </div>
            ) : (
              <div className="message-list">
                {messages.map((message) => (
                  <article
                    className={`chat-message ${message.role === 'user' ? 'from-user' : 'from-assistant'}`}
                    key={message.id}
                    data-testid={`message-${message.role}-${message.id}`}
                  >
                    <span className="message-speaker">{message.role === 'user' ? 'You' : 'StudyMate AI'}</span>
                    <div className="message-bubble">{message.content}</div>
                    {message.status === 'not_implemented' && (
                      <span className="message-tool-note">This tool is planned for a later phase.</span>
                    )}
                    {message.tool === 'academic_qa' && message.status === 'complete' && (
                      <span className="message-tool-note">Academic Q&amp;A · Gemini</span>
                    )}
                  </article>
                ))}
                {agentRequest.isPending && (
                  <div className="chat-message from-assistant" data-testid="status-ai-loading">
                    <span className="message-speaker">StudyMate AI</span>
                    <div className="message-bubble loading-bubble">
                      <LoaderCircle size={15} className="loading-spinner" aria-hidden="true" />
                      Thinking through your question…
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
          <div className="chat-composer">
            {requestError && (
              <div className="chat-error" role="alert" data-testid="status-ai-error">
                <span>{requestError}</span>
                <button
                  type="button"
                  className="retry-button"
                  onClick={retryLastQuestion}
                  disabled={agentRequest.isPending}
                  data-testid="button-retry-question"
                >
                  Try again
                </button>
              </div>
            )}
            <form className="composer-box" onSubmit={handleSubmit}>
              <input
                aria-label="Ask StudyMate a question"
                placeholder="Ask a question about your studies…"
                value={draft}
                onChange={(event) => setDraft(event.target.value)}
                disabled={agentRequest.isPending}
                data-testid="input-ai-question"
              />
              <button
                type="submit"
                aria-label="Send question"
                disabled={!draft.trim() || agentRequest.isPending}
                data-testid="button-send-question"
              >
                {agentRequest.isPending
                  ? <LoaderCircle size={16} className="loading-spinner" aria-hidden="true" />
                  : <Send size={16} />}
              </button>
            </form>
            <p className="chat-footnote" data-testid="text-ai-phase-note">
              Academic Q&amp;A is active. Study planning, attendance analysis, summaries and reports are planned for later phases.
            </p>
          </div>
        </section>
        <div className="welcome-row" style={{ marginTop: 19 }}>
          <p className="section-description" style={{ margin: 0 }}>Not sure where to start? Explore a tool preview instead.</p>
          <Link href="/summarize-material" className="small-link" data-testid="link-explore-summarize">Explore summarization <ArrowRight size={14} /></Link>
        </div>
      </div>
    </main>
  );
}

function NotFound() {
  return (
    <main className="page-wrap" data-testid="page-not-found">
      <div className="page-heading"><div><div className="eyebrow">A small detour</div><h1>That page isn’t here.</h1><p>The link may have moved. Head back to your dashboard to find your way around.</p></div></div>
      <Link href="/" className="button-primary" data-testid="link-return-dashboard">Return to dashboard <ArrowRight size={15} /></Link>
    </main>
  );
}

function PageRouter() {
  const [location] = useLocation();
  const active = pages.some((page) => page.href === location) ? location : '/';
  return (
    <Shell active={active}>
      <RoutedErrorBoundary>
        <Switch>
          <Route path="/" component={HomePage} />
          <Route path="/ask-ai" component={AskAiPage} />
          <Route path="/study-planner" component={StudyPlannerPage} />
          <Route path="/summarize-material"><FeaturePreview kind="summary" /></Route>
          <Route path="/attendance-analyzer"><FeaturePreview kind="attendance" /></Route>
          <Route path="/report-generator"><FeaturePreview kind="report" /></Route>
          <Route component={NotFound} />
        </Switch>
      </RoutedErrorBoundary>
    </Shell>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <PageRouter />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;

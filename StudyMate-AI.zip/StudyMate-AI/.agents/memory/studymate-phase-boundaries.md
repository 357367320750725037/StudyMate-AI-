---
name: StudyMate phase boundaries
description: Scope rule for distinguishing the current StudyMate AI phase from later feature work.
---

StudyMate AI is being built in phases. Implement only the features included in the latest phase the user explicitly requests. Keep tools without real behavior clearly unavailable; never return fabricated answers, plans, summaries, attendance analysis, or reports.

StudyMate must stay on Replit's free plan and use the user's Gemini API key from the server-side `GEMINI_API_KEY` secret rather than Replit's paid AI integration.

**Why:** The user explicitly ruled out upgrading Replit and asked for Gemini through a server-side secret. They also asked that unimplemented features not be presented as working.

**How to apply:** Check the latest request to establish phase scope. Keep Gemini calls in the API server and never expose the secret in client code. Label any deferred tools honestly until they have real behavior.
